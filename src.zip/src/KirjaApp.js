import React from 'react';
import './App.css';
import Kirjalomake from './components/Kirjalomake';
import KirjaLista from './components/KirjaLista';
//import Tiedonhaku from './components/Tiedonhaku';

//LISTA OBJECTI korvataan 2 vaiheessa oikealla kannalla
const kirjatlistassa = [
    {
        id: 1,
        nimi: 'Sieni kirja',
        kirjailija: 'Tove Ansa'
    },

    {
        id: 2,
        nimi: 'Lemmikit',
        kirjailija: 'Hasse Piu'
    }
,
    {
        id: 3,
        nimi: 'Lemmikit kesälomalla',
        kirjailija: 'Hasse Piu'
    }
];

function KirjaApp() {
return(
    <div className='App'>
        <h1>Lukemani ja kuuntelemani kirjat talteen:</h1>
        <p>Anna lukemasi kirjan nimi ja kirjailijan nimi</p>

    <Kirjalomake/>
    <KirjaLista kirjat={kirjatlistassa}/>
    {/*<Tiedonhaku />*/}
    </div>
);

}

export default KirjaApp;
import React, {useState, useEffect} from 'react';
import { async } from 'q';
import { isValidES3Identifier } from '@babel/types';

//en saanut tietoa ulos,harjoitukset jatkuvat
//https://api.finna.fi/v1/<toiminto>?<parametrit>
//https://www.kiwi.fi/display/Finna/Finnan+avoin+rajapinta

//harjoittelua

function Tiedonhaku () {

    //tähän muuttuvat const (eli mitä haetaan)
    //ja alustus useState avulla
    //esim const [title, setTitle] = useState("");
    //const [viesti, setVirhe] = useState('Haetaan tietoja ...');

    //tähän tietojenhaku functio
    async function fetrcUrl() {

        try {

            const response = await fetch('')

            //muutetaan sitten json muotoon
            //const json = await.response.json();

            //sitten asetetaan saatu tieto ja virhe tyhjäksi

            //esim  setTitle(json.items[0].title);
            // setVirhe("");

        } catch (error) {
            //jos haku ei onnnistu
            setVirhe('Tiedonhaku ei onnistunut');
            console.log(error); //errori logiin
        }
    }

    //tässä useEffectin avulla tehdään tämä aina kun komponentti aukee ekan kerran
    //if lauseella tulostuu joko haettu tieto 
    //jos ei tule vielä tietoa niin tulostuu viestin sisältö
//[] - kertoo, että toteutetaan vain komponentin alussa kerran
    useEffect(() => {fetrcUrl()}, []);

    if (viesti.length > 0){
        return(<div>{viesti}</div>)
    }

    return()//tähän miten haluat haetut tiedot sivulle)
    //esim (<div>{title} <br/> {enclosure}</div>)
}

export default Tiedonhaku;

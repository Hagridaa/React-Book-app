import React, {useState} from 'react';

//drop down valikko, josta voi valita pitikö kirjasta vai ei?

function Kirjalomake () {

    const [kirja, setValues] = useState ({

        nimi: "",
        kirjailija: ""
    });

    const muuta = (e) => {

        setValues({
            ...kirja, [e.target.name]: e.target.value
        });

        }

        const lisaa = (e) => {
            e.preventDefault();
            setValues({
            nimi: "",
            kirjailija: ""
            });

        }

    return (
        <div>
        <form>
            <label style={{backgroundColor: 'pink'}}>Kirjan nimi: </label>
            <input type="text" name="nimi" value={kirja.nimi} onChange={ (e) => muuta(e)}/> <br/>

            <label style={{backgroundColor: 'pink'}}>Kirjailia: </label>
            <input type="text" name="kirjailija" value={kirja.kirjailija} onChange={ (e) => muuta(e)}/> <br/> <br/>

            <br/>
            <input type="submit" value="lisää" onClick={(e) => lisaa(e)}/>
        </form>

        </div>

        
    )

}
export default Kirjalomake; 
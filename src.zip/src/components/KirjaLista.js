import React from 'react';

function KirjaLista (props) {
    return (
        
        <div>
            <h1>Kirjat listassa:</h1>
            {props.kirjat.map(kirja => {
            return(
                <p key={kirja.id}>
                    Kirjan nimi: {kirja.nimi}<br />
                    Kirjailija: {kirja.kirjailija}
                    </p>
            )
            })
            }
        </div>
    )
}

export default KirjaLista;